
describe('hello', function(){
  it('should just say hello', function(){
    'hello world'.should.equal('hello world');
  });
}); 