//main.js must be here for optimize to work
require(function () {
	
});